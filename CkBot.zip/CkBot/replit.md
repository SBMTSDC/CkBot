# CK Bot - Discord Event Registration Bot

## Overview

CK Bot is a Discord bot designed for managing event registrations for gaming sessions. The bot allows users to register for specific time slots on weekends (Saturday and Sunday at 15:00 and 20:00) and automatically resets registrations every Monday. It's built using Python with the discord.py library and includes a Flask-based keep-alive mechanism for continuous operation on hosting platforms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Discord.py Library**: Uses the modern discord.py library with slash commands for user interaction
- **Command System**: Implements both traditional command prefix system and modern slash commands using app_commands
- **Event-Driven Architecture**: Built around Discord's event system with async/await patterns

### Data Management
- **In-Memory Storage**: Uses Python dictionaries to store registration data temporarily
- **Data Structure**: Registration data organized by day-time tuples with player lists
- **Capacity Management**: Enforces a maximum of 10 players per time slot

### Scheduling System
- **Automated Reset**: Implements a weekly reset system using discord.ext.tasks
- **Time-Based Logic**: Resets all registrations every Monday at midnight using datetime checks
- **Loop Tasks**: Uses @tasks.loop decorator for periodic operations

### Keep-Alive Mechanism
- **Flask Web Server**: Runs a minimal Flask application to maintain bot uptime
- **Threading**: Utilizes separate threads to run both Discord bot and Flask server simultaneously
- **Health Check Endpoint**: Provides a simple endpoint to verify bot status

### User Interface
- **Slash Commands**: Modern Discord slash command interface with dropdown selections
- **Parameterized Commands**: Uses app_commands.choices for structured input (day/time selection)
- **Responsive Feedback**: Provides immediate user feedback for registration attempts

### Configuration Management
- **Environment Variables**: Uses environment variables for sensitive configuration (Discord token)
- **Fallback Values**: Implements default values for development environments

## External Dependencies

### Discord Platform
- **Discord API**: Core integration through discord.py library for bot functionality
- **Discord Gateway**: Real-time connection for receiving events and commands
- **Discord Slash Commands**: Modern command interface requiring API registration

### Python Libraries
- **discord.py**: Primary library for Discord bot functionality and API interaction
- **Flask**: Lightweight web framework for the keep-alive server
- **threading**: Python standard library for concurrent execution

### Hosting Requirements
- **Environment Variables**: Requires DISCORD_TOKEN environment variable
- **Port Configuration**: Uses PORT environment variable with fallback to 5000
- **Continuous Runtime**: Designed for platforms requiring keep-alive mechanisms (like Replit)

### Time and Scheduling
- **datetime**: Python standard library for time-based operations and scheduling logic
- **Korean Time Zone**: Operates on Korean Standard Time (KST) for Monday reset functionality